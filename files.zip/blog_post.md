# When Prophet Beats Z-Score — and When It Doesn't

## A Practical Anomaly Detection Benchmark on Real Sensor Data

Most anomaly detection tutorials use toy datasets with obvious, synthetic anomalies. This one doesn't. I benchmarked six methods against real-world machine sensor data from the Numenta Anomaly Benchmark (NAB) — a dataset where anomalies are rare, messy, and genuinely hard to find.

The short version: Prophet generalises better across stream types, but a simple z-score wins on clean, high-amplitude anomalies. Here's what that means and why it matters.

---

## The Dataset

The NAB `machine_temperature_system_failure` stream is 22,683 rows of 5-minute temperature readings from an industrial machine. There are **4 anomaly events** in the entire series — equipment failure signatures buried in months of normal operation. That's a 0.02% positive rate.

This matters because most tutorials inflate their anomaly rates to make F1 look good. At 0.02%, F1 is near-zero for every method regardless of quality. The right metrics here are **AUROC** (how well the method ranks anomalies above normals, threshold-free) and **Average Precision** (area under the precision-recall curve, which respects class imbalance).

I also had to be careful with the labels. NAB ships two label files: `combined_windows.json` marks wide time windows (up to 47 hours) around each event for partial-credit scoring. `combined_labels.json` marks the actual event timestamps. Using windows as point labels inflates the anomaly rate to ~10% and makes every metric meaningless. I used point labels throughout.

---

## The Methods

Six detectors, ordered roughly by complexity:

**Z-Score** — Compute train mean and std. Flag points where `|x - μ| / σ` exceeds a threshold. One line of math, zero hyperparameters.

**Rolling MAD** — Median absolute deviation over a rolling window. Robust to outliers in the baseline. Warm-started across split boundaries so the window has history from the previous split at evaluation time.

**STL** — Seasonal-Trend decomposition via LOESS. Separates the series into trend, seasonality, and residual. Anomaly score is the residual magnitude. Offline method — it sees the full series, so it's retrospective, not causal.

**Mean-Window Discord** — Divides the series into overlapping windows, z-normalises each, computes distance to the mean train window. High distance = unusual pattern. This is not the matrix profile (which uses nearest-neighbour distance) — it's a simpler discord baseline fitted on train windows only.

**Prophet** — Facebook's forecasting library. Fits an additive model with trend and seasonality components on the training split, then forecasts on the test split. Anomaly score is the absolute forecast residual. It explicitly models daily and weekly cycles.

**LSTM** — A single-layer LSTM forecaster. Trained on the training split with early stopping on a held-out portion. Standardisation uses train statistics only. Anomaly score is the absolute difference between predicted and actual value.

---

## Evaluation Protocol

Split: 70% train, 30% test, time-ordered. Thresholds are tuned on the test split itself (val = test), which means F1 is optimistic. AUROC and AP are threshold-free and unaffected by this.

Scaling: each method's raw scores are min-max scaled using train statistics, then applied to test. This keeps the score scale consistent so a threshold set on one split is actually meaningful on another.

---

## Results

| Method | Test AUROC | Test AP |
|---|---|---|
| Z-Score | **0.965** | **0.946** |
| Prophet | 0.890 | 0.825 |
| LSTM | 0.559 | 0.143 |
| Rolling MAD | 0.516 | 0.132 |
| STL | 0.449 | 0.089 |
| Mean-Window Discord | 0.346 | 0.074 |

Z-Score wins on this stream. That's the honest result and it's worth understanding why before dismissing it.

---

## Why Z-Score Wins Here

The machine temperature failure manifests as a large, sustained deviation — the temperature drops sharply and stays anomalous for days. A z-score excels at exactly this: the deviation is large relative to the train distribution, so it scores high. No sophistication needed.

Prophet gets AUROC 0.890, which is strong. But Z-Score gets 0.965. The gap exists because Prophet's forecast residual is noisier than raw deviation — the model is doing more work (fitting trend and seasonality) and some of that work introduces error.

This is an important lesson that simple baselines frequently beat complex models on clean, high-amplitude anomalies. The complexity of a method does not predict its performance on a given stream.

---

## Where Prophet Has the Advantage

On cloud CPU utilisation streams — like `ec2_cpu_utilization_5f5533` — the pattern is different. CPU usage has a pronounced daily cycle: high during business hours, low at night. An anomaly is a deviation from this cycle, not a deviation from a flat mean.

Z-Score on this stream: AUROC 0.479 — worse than random.

Prophet on this stream: AUROC 0.869.

The difference is that Prophet explicitly models the daily cycle as a seasonality component. Its residuals measure "how far is this from what the model expected given the time of day?" Z-Score measures "how far is this from the overall mean?" Those are different questions, and on periodic data, only one of them is correct.

This is the genuine insight from the benchmark: **Prophet's value is proportional to how much seasonality exists in the stream**. On flat or trend-dominated series, z-score competes or wins. On streams with meaningful daily/weekly cycles, Prophet pulls ahead substantially.

---

## What Didn't Work

**LSTM** underperformed significantly (AUROC 0.559 on machine_temp). With only 13,000 training rows and a 48-step window, the model doesn't have enough signal to learn a useful forecast. It also trains on clean data and sees the failure regime for the first time at test time — a distribution shift the architecture has no mechanism to handle gracefully.

**STL** is offline — it decomposes the full test split, so it has future context. Despite this, it scores 0.449 AUROC. The residuals are too noisy relative to the anomaly magnitude.

**Mean-Window Discord** scores 0.346 — the worst result. The mean reference window is computed on train data where the machine was operating normally. When the failure pattern is genuinely unlike anything in train, the method should score high. It doesn't, likely because the distance metric is too sensitive to short-term variation during the normal operating period.

---

## Implementation Notes Worth Knowing

A few details that actually changed the results:

**Off-grid label timestamps.** NAB's `combined_labels.json` timestamps don't align to the 5-minute CSV grid — anomaly events are logged at times like `02:04` while the series rows are at `00:00, 00:05, 00:10...`. Exact timestamp matching silently drops all labels. The fix is `merge_asof` with a 5-minute tolerance.

**Per-split score scaling breaks frozen thresholds.** If you min-max scale train, val, and test scores independently, a threshold of `0.3` means different things in each split. The threshold is nominally "frozen" but the score it's applied to has been rescaled. You end up evaluating nothing meaningful. The fix: fit the scaler on train scores only, apply to all splits.

**Rolling window cold start.** A rolling MAD window computed from scratch at the start of the test split has no history — the first 48 rows use partial windows and produce noisy scores. The fix: prepend the last 47 rows of train before computing test scores, then drop them from the output.

None of these are dramatic bugs. All of them silently degrade results without error messages.

---

## What to Take Away

Use AUROC and AP as your primary metrics on sparse anomaly data. F1 is unreliable when positive rate is below 1%.

Prophet is not always the best method. It's the most *consistent* method across stream types. If you know your data has strong seasonality, it's the right starting point. If your anomalies are large-amplitude deviations from a flat baseline, z-score will match or beat it with a fraction of the complexity.

The hardest part of this project wasn't the models — it was getting the evaluation right. Wrong label files, leaking scale parameters, cold-start artefacts: all of these are invisible unless you go looking for them.

---

*Code and notebook: [github link]. Dataset: [NAB on GitHub](https://github.com/numenta/NAB).*
